from my_package import module1, module2

result_add = module1.add(5, 3)
result_multiply = module2.multiply(5, 3)

print(f"Addition: {result_add}")
print(f"Multiplication: {result_multiply}")
